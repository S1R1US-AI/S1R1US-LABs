import { createServerFn } from "@tanstack/react-start";
import { verifyAccessToken } from "@/lib/desk/access.server";
import { cloudflareDns, guardedFetch } from "@/lib/desk/net-guard";
import { COIN_DOMAIN } from "./model";

const hits: number[] = [];
function throttle() {
  const now = Date.now();
  while (hits.length && now - hits[0]! > 60_000) hits.shift();
  if (hits.length >= 20) return true;
  hits.push(now);
  return false;
}

export type SiteHealth = {
  at: string;
  apexA: string[];
  wwwCname: string[];
  ns: string[];
  http: { status: string; body: string };
  tls: string;
  verdict: string;
};

async function dnsJson(name: string, type: "A" | "NS" | "CNAME") {
  const j = await cloudflareDns(name, type);
  return (j.Answer ?? []).map((a) => String(a.data ?? "").replace(/\.$/, ""));
}

export const probeSiteHealth = createServerFn({ method: "POST" })
  .validator((input: { token: string }) => input)
  .handler(async ({ data }): Promise<SiteHealth> => {
  if (!(await verifyAccessToken(data.token))) {
    return {
      at: new Date().toISOString(),
      apexA: [],
      wwwCname: [],
      ns: [],
      http: { status: "401", body: "admin" },
      tls: "skipped",
      verdict: "Admin session required.",
    };
  }
  if (throttle()) {
    return {
      at: new Date().toISOString(),
      apexA: [],
      wwwCname: [],
      ns: [],
      http: { status: "429", body: "health probe capped" },
      tls: "skipped",
      verdict: "Slow down — health probe is rate-limited.",
    };
  }
  const apex = COIN_DOMAIN;
  const [apexA, wwwCname, ns] = await Promise.all([
    dnsJson(apex, "A"),
    dnsJson(`www.${apex}`, "CNAME"),
    dnsJson(apex, "NS"),
  ]);

  let http = { status: "ERR", body: "" };
  let tls = "unknown";
  try {
    const r = await guardedFetch(`https://${apex}/`, { redirect: "manual" } as RequestInit);
    const body = (await r.text()).replace(/\s+/g, " ").slice(0, 180);
    http = { status: String(r.status), body };
    tls = `HTTPS ${r.status}`;
  } catch (e) {
    http = { status: "ERR", body: e instanceof Error ? e.message : "fetch failed" };
    tls = e instanceof Error ? e.message : "TLS failed";
  }

  const notFound = /DEPLOYMENT_NOT_FOUND/i.test(http.body);
  const onVercel = apexA.includes("76.76.21.21");
  const verdict = notFound
    ? "DNS reaches Vercel, but no published app owns s1r1us.ai. Publish in Grok, then add this domain — do not change GoDaddy yet."
    : tls.startsWith("HTTPS 2")
      ? "HTTPS is up. Open https://s1r1us.ai/s1r1us"
      : onVercel
        ? "Apex is on Vercel anycast. SSL will stay invalid until the domain is attached to a published project."
        : "Apex A is not 76.76.21.21 — copy the records Grok Publish shows, not a guess.";

  return {
    at: new Date().toISOString(),
    apexA,
    wwwCname,
    ns,
    http,
    tls,
    verdict,
  };
});
